package pl.nygus.live

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
  private lateinit var web: WebView
  private var pendingEndpoint = ""
  private var pendingContentUrl = "file:///android_asset/dashboard.html"
  private var pendingAudioMode = 0

  private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
    if (granted) requestCapture() else toastJs("Brak zgody na mikrofon")
  }

  private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
    if (result.resultCode == Activity.RESULT_OK && result.data != null) {
      val i = Intent(this, StreamService::class.java).apply {
        action = StreamService.ACTION_START
        putExtra(StreamService.EXTRA_RESULT_CODE, result.resultCode)
        putExtra(StreamService.EXTRA_DATA, result.data)
        putExtra(StreamService.EXTRA_ENDPOINT, pendingEndpoint)
        putExtra(StreamService.EXTRA_AUDIO_MODE, pendingAudioMode)
      }
      ContextCompat.startForegroundService(this, i)
      web.loadUrl(pendingContentUrl)
    } else toastJs("Anulowano przechwytywanie ekranu")
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    web = findViewById(R.id.web)
    web.settings.javaScriptEnabled = true
    web.settings.domStorageEnabled = true
    web.settings.mediaPlaybackRequiresUserGesture = false
    web.settings.allowFileAccess = true
    web.webViewClient = WebViewClient()
    web.webChromeClient = WebChromeClient()
    web.addJavascriptInterface(Bridge(), "Android")
    web.loadUrl("file:///android_asset/index.html")
  }

  override fun onBackPressed() {
    if (web.url != "file:///android_asset/index.html") web.loadUrl("file:///android_asset/index.html")
    else super.onBackPressed()
  }

  inner class Bridge {
    @JavascriptInterface fun openUrl(url: String) = runOnUiThread { web.loadUrl(safeUrl(url)) }

    @JavascriptInterface fun startLive(contentUrl: String, endpoint: String, audioMode: Int) = runOnUiThread {
      if (!(endpoint.startsWith("rtmp://") || endpoint.startsWith("rtmps://"))) {
        toastJs("Nieprawidłowy adres RTMP/RTMPS")
        return@runOnUiThread
      }
      pendingContentUrl = safeUrl(contentUrl)
      pendingEndpoint = endpoint
      pendingAudioMode = audioMode.coerceIn(0, 2)
      if (pendingAudioMode != 0 && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
      } else requestCapture()
    }

    @JavascriptInterface fun stopLive() = runOnUiThread {
      startService(Intent(this@MainActivity, StreamService::class.java).setAction(StreamService.ACTION_STOP))
      toastJs("LIVE zatrzymany")
    }
  }

  private fun requestCapture() {
    val projection = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
    captureLauncher.launch(projection.createScreenCaptureIntent())
  }

  private fun safeUrl(raw: String): String {
    val u = raw.trim()
    return when {
      u.isBlank() -> "file:///android_asset/dashboard.html"
      u.startsWith("https://") || u.startsWith("http://") || u.startsWith("file://") -> u
      else -> "https://$u"
    }
  }

  private fun toastJs(message: String) {
    val safe = message.replace("\\", "\\\\").replace("'", "\\'")
    web.evaluateJavascript("if(window.setStatus){setStatus('$safe')}", null)
  }
}
